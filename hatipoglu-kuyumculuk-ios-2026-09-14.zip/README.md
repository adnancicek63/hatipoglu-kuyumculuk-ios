# Hatipoğlu Kuyumculuk - Canlı Altın & Döviz Fiyatları iOS & Web

Hatipoğlu Kuyumculuk için geliştirilmiş profesyonel canlı altın, döviz ve borsa takip sistemi.

## 🚀 Hızlı Başlangıç

```bash
# Bağımlılıkları yükleyin
npm install

# Geliştirme sunucusunu başlatın
npm run dev

# iOS için derleyin
npm run build
npx cap sync ios
```

## 📱 Codemagic.io CI/CD
Proje kökünde hazır `codemagic.yaml` yer almaktadır. GitHub'a yükleyip Codemagic'e bağladığınızda doğrudan TestFlight ve App Store için IPA derlemesi alabilirsiniz.
